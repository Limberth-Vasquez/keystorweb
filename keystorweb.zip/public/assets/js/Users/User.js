class User {
    constructor() {
        this.id = '';
        this.name = '';
        this.lastName = '';
        this.secondLastName = '';
        this.personalID = '';
        this.password = '';
        this.email = '';
        this.phoneNumber = '';
        this.lat = '';
        this.lng = '';
        this.rolID = '';
        this.active = '';
        this.keystorApproved = '';
        this.creationDate = '';
    }
}