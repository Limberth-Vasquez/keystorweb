class AboutUs {
    constructor(){        
        this.id = '';
        //this.title = '';
        //this.description = '';
        this.active = '';
        this.descAboutUs1 = '';
        this.titleh2 = '';
        this.titleh3 = '';
        this.shortDescp = '';
        this.li1 = '';
        this.li2 = '';
        this.li3 = '';
    }
}