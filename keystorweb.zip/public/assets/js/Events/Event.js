class Event {
    constructor() {
        this.id = '';
        this.description = '';
        this.name = '';
        this.Lat = '';
        this.Lng = '';
        this.address = '';
        this.imageUrl = '';


        this.email = '';
        this.phone = '';
        this.thisOwner = '';
        this.fees1 = '';
        this.fees2 = '';
        this.fees3 = '';
    }
}