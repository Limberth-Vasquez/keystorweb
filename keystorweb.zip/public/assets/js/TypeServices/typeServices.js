class TypeService {
    constructor(){        
        this.id = '';
        this.name = '';
        this.active = '';
    }
}