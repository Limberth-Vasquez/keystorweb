$(() => {
    firebase.initializeApp(config);
    // const auth = firebase.auth();
    // const db = firebase.firestore();

    // console.log(firebase);
})