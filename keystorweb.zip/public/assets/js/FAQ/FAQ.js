class FAQ {
    constructor(){        
        this.id = '';
        this.question = '';
        this.answer = '';
        this.active = '';
    }
}