const config  = {
    apiKey: "AIzaSyCoKctrjwaIvgguxVikiFNMupbL6fUzDQA",
    authDomain: "keystore-b18e4.firebaseapp.com",
    databaseURL: "https://keystore-b18e4.firebaseio.com",
    projectId: "keystore-b18e4",
    storageBucket: "keystore-b18e4.appspot.com",
    messagingSenderId: "1082799348546",
    appId: "1:1082799348546:web:2f3724d678f5b4fa6486db",
    measurementId: "G-SNN8V9S645"
}