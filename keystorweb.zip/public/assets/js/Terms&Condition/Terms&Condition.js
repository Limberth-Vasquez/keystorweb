class TermsAndCondition {
    constructor(){        
        this.id = '';
        this.title = '';
        this.description = '';
        this.active = '';
    }
}